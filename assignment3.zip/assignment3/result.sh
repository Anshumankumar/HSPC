#!/bin/bash

echo "Nvidia Processor"
./matMul > "report/nvidia.txt"
