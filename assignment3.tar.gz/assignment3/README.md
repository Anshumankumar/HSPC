###Introduction
This code is written for assignment 3 of course High Performance Scientific
Computing. It shows the performance of nvidia processor in matrix
multiplication.It consist of two exeutable

1. matMul- uses Nvidia
2. matMulD- Uses Messages and print Debug

###Running Instruction
for generating the report run
```
make clean
make
./result.sh
```

For generating report
```
make report
```

The results are generated for report folder
