###Introduction
This code is written for assignment 2 of course High Performance Scientific
Computing. It shows the performance of openMp, mpi and single thread matrix
multiplication.It consist of three exeutable

1. mpi_main- uses mpi
2. main-  single thread
3. oMpMain- uses openMp

###Running Instruction
for generating the report run
```
make clean
make
./result.sh
```

For generating report
```
make report
```

The results are generated for report folder
